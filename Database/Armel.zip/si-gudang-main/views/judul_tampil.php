<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <h2>Menu Judul !</h2>
        </div>
    </div>
</div>

