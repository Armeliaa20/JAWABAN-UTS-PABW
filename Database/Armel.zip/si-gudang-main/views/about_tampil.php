<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title"><span class="fa fa-user-plus"></span> About</h3>
                </div>
                <div class="panel-body">
                    <table id="dtskripsi" class="table table-bordered table-striped table-hover">
                        <thead>
                            <p align="center"><img src="img/gudang.jpg"></img></p>
                            <label class="col-sm-12 control-label"><center><strong>SISTEM INFORMASI INVENTORY GUDANG  <br> PT.SUMBER NELAYAN INDONESIA</strong></center></label>
                        </thead>
                        <tbody>
                          <div class="col-sm-2" align="center">

                          </div>
                          <div class="col-sm-8" align="center">
                            <br>
                            <thead>
                           <label class="col-sm-12 control-label"><center><strong>NAMA : <br> RINALDI SIAGIAN<br>EMY SAZUWAN SYAHPUTRA<br>GILANG HERMAWAN</strong></center></label>
                        </thead>
                            <br><br><br>
                          </div>
                          <div class="col-sm-2" align="center">
                          </div>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
