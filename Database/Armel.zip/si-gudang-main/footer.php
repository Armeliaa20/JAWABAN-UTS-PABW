<div class="container">
    <div class="row">
        <div class="col-xs-12">
            Copyright &COPY; <?= date('Y')?> Armelia |
        </div>
    </div>
</div>
